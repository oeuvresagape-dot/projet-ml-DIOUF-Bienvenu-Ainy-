"""Module d'entraînement : compare plusieurs modèles, retient le meilleur (selon le score F1 pour la classe attaque)
et l'enregistre dans models/model.joblib."""

from pathlib import Path
import logging
import joblib
import pandas as pd

from sklearn.compose import ColumnTransformer
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, f1_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier

# Configuration du logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

# Chemins et constantes
ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data" / "flux_train.csv"
MODEL = ROOT / "models" / "model.joblib"
SEED = 42

NUMERIC_FEATURES = [
    "duration", "dst_port", "src_bytes", "dst_bytes",
    "nb_packets", "nb_failed_logins", "nb_conn_same_host", "syn_rate"
]
CATEGORICAL_FEATURES = ["protocol"]


def build_pipeline(clf) -> Pipeline:
    """Construit un pipeline complet incluant le prétraitement (imputation, mise à l'échelle, one-hot) et le classifieur."""
    numeric_transformer = Pipeline([
        ("imp", SimpleImputer(strategy="median")),
        ("sc", StandardScaler())
    ])

    categorical_transformer = Pipeline([
        ("imp", SimpleImputer(strategy="most_frequent")),
        ("oh", OneHotEncoder(handle_unknown="ignore"))
    ])

    preprocessor = ColumnTransformer([
        ("num", numeric_transformer, NUMERIC_FEATURES),
        ("cat", categorical_transformer, CATEGORICAL_FEATURES)
    ])

    return Pipeline([("pre", preprocessor), ("clf", clf)])


def main() -> None:
    """Fonction principale d'entraînement, d'évaluation et de sauvegarde du meilleur modèle."""
    if not DATA.exists():
        logging.error(f"Le fichier de données est introuvable à l'emplacement : {DATA}")
        raise FileNotFoundError(f"Données introuvables : {DATA}")

    logging.info(f"Chargement des données depuis {DATA}...")
    df = pd.read_csv(DATA)

    logging.info(f"Taille du dataset : {df.shape}")
    missing_vals = df.isna().sum()
    if missing_vals.any():
        logging.info("Valeurs manquantes par colonne :\n%s", missing_vals[missing_vals > 0])

    logging.info("Répartition de la cible 'attaque' :\n%s", df["attaque"].value_counts(normalize=True).round(3))

    X = df[NUMERIC_FEATURES + CATEGORICAL_FEATURES]
    y = df["attaque"]

    # Division stratifiée pour conserver la proportion des classes
    X_tr, X_val, y_tr, y_val = train_test_split(
        X, y, test_size=0.25, stratify=y, random_state=SEED
    )

    # Dictionnaire des modèles candidats
    candidats = {
        "Régression logistique": LogisticRegression(max_iter=1000, class_weight="balanced", random_state=SEED),
        "Arbre de décision": DecisionTreeClassifier(max_depth=6, class_weight="balanced", random_state=SEED),
        "Forêt aléatoire": RandomForestClassifier(n_estimators=300, class_weight="balanced", random_state=SEED, n_jobs=-1),
        # Note : GradientBoostingClassifier ne supporte pas nativement class_weight='balanced'
        "Gradient Boosting": GradientBoostingClassifier(random_state=SEED),
    }

    scores = {}
    for nom, clf in candidats.items():
        logging.info(f"Entraînement et évaluation du modèle : {nom}...")
        pipe = build_pipeline(clf).fit(X_tr, y_tr)
        pred = pipe.predict(X_val)

        # Calcul du score F1 (average='binary' par défaut, cible la classe positive/attaque)
        scores[nom] = f1_score(y_val, pred, pos_label=1)

        print(f"\n===== {nom} =====")
        print(classification_report(y_val, pred, target_names=["normal", "attaque"], digits=3))
        tn, fp, fn, tp = confusion_matrix(y_val, pred).ravel()
        print(f"Matrice de confusion : VN={tn} FP={fp} FN={fn} VP={tp}")

    meilleur = max(scores, key=scores.get)
    logging.info(f"Meilleur modèle sélectionné : {meilleur} (F1 attaque = {scores[meilleur]:.3f})")

    # Ré-entraînement sur l'intégralité des données (X, y) pour maximiser les performances en production
    logging.info("Ré-entraînement du meilleur modèle sur l'ensemble des données...")
    final_pipeline = build_pipeline(candidats[meilleur]).fit(X, y)

    # Sauvegarde du pipeline complet
    MODEL.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(final_pipeline, MODEL)
    logging.info(f"Modèle sauvegardé avec succès à l'emplacement : {MODEL}")


if __name__ == "__main__":
    main()