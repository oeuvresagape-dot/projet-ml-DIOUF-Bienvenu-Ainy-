"""Module de prédiction : charge models/model.joblib (Pipeline complet) et effectue des prédictions."""

from pathlib import Path
import logging
import joblib
import pandas as pd

# Configuration du logging pour un suivi propre
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

# Chemins d'accès relatifs basés sur l'emplacement du fichier
BASE_DIR = Path(__file__).resolve().parent.parent
MODEL_PATH = BASE_DIR / "models" / "model.joblib"
DATA_PATH = BASE_DIR / "data" / "flux_train.csv"

_model = None

def load_model() -> object:
    """Charge le modèle joblib en mémoire de manière sécurisée."""
    global _model
    if _model is None:
        if not MODEL_PATH.exists():
            logging.error(f"Le fichier modèle est introuvable à l'emplacement : {MODEL_PATH}")
            raise FileNotFoundError(f"Modèle introuvable : {MODEL_PATH}")

        try:
            logging.info(f"Chargement du modèle depuis {MODEL_PATH}...")
            _model = joblib.load(MODEL_PATH)
            logging.info("Modèle chargé avec succès.")
        except Exception as e:
            logging.error(f"Erreur lors du chargement du modèle : {e}")
            raise
    return _model

def predict(df: pd.DataFrame) -> list[int]:
    """
    Effectue des prédictions à partir d'un DataFrame.

    Paramètres :
    -----------
    df : pd.DataFrame
        Contient les mêmes colonnes que flux_train.csv (la colonne 'attaque' peut être présente ou absente).

    Retourne :
    ---------
    list[int]
        Une liste d'entiers : 0 (normal) ou 1 (attaque), une valeur par ligne.
    """
    if df is None or df.empty:
        logging.warning("Le DataFrame fourni est vide.")
        return []

    model = load_model()

    # Suppression de la colonne cible 'attaque' si elle est présente dans le jeu de données
    X = df.drop(columns=["attaque"], errors="ignore")

    try:
        predictions = model.predict(X)
        return [int(p) for p in predictions]
    except Exception as e:
        logging.error(Soucis lors de la phase de prédiction : {e})
        raise


if __name__ == "__main__":
    try:
        if DATA_PATH.exists():
            logging.info(f"Lecture des données de test depuis {DATA_PATH}...")
            data = pd.read_csv(DATA_PATH)

            # Test de prédiction sur les 10 premières lignes
            resultats = predict(data.head(10))
            print("Résultats des prédictions (10 premières lignes) :", resultats)
        else:
            logging.warning(f"Fichier de données par défaut introuvable : {DATA_PATH}")
    except Exception as e:
        logging.error(f"Une erreur est survenue lors de l'exécution du script : {e}")